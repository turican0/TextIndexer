extends Control

const MIN_FONT_SIZE := 16
const MAX_FONT_SIZE := 64
const FONT_STEP := 4

@onready var text_label: TextEdit = $VBoxContainer/TextLabel
@onready var back_button: Button = $VBoxContainer/BottomBar/BackButton
@onready var minus_button: Button = $VBoxContainer/BottomBar/MinusButton
@onready var plus_button: Button = $VBoxContainer/BottomBar/PlusButton
@onready var title_label: Label = $VBoxContainer/TitleLabel


func _ready() -> void:
	back_button.pressed.connect(_on_back_pressed)
	minus_button.pressed.connect(_on_minus_pressed)
	plus_button.pressed.connect(_on_plus_pressed)

	var path: String = Indexer.current_reader_path
	var parent_dir := path.get_base_dir().get_file()
	title_label.text = "%s / %s" % [parent_dir, path.get_file()] if parent_dir != "" else path.get_file()
	text_label.text = Indexer.get_reader_text(path)

	# Barvy nastavujeme napevno v kódu (nezávisle na globálním motivu),
	# aby text nemohl nikdy skončit jako bílý na bílém pozadí.
	title_label.add_theme_color_override("font_color", Color.BLACK)
	text_label.add_theme_color_override("font_color", Color.BLACK)

	title_label.add_theme_font_size_override("font_size", 44) # Větší titulek souboru

	if Indexer.reader_font_size < MIN_FONT_SIZE or Indexer.reader_font_size > MAX_FONT_SIZE:
		Indexer.reader_font_size = 36
	_apply_font_size()


func _apply_font_size() -> void:
	text_label.add_theme_font_size_override("font_size", Indexer.reader_font_size)


func _on_minus_pressed() -> void:
	Indexer.reader_font_size = max(MIN_FONT_SIZE, Indexer.reader_font_size - FONT_STEP)
	_apply_font_size()
	Indexer.save_settings()


func _on_plus_pressed() -> void:
	Indexer.reader_font_size = min(MAX_FONT_SIZE, Indexer.reader_font_size + FONT_STEP)
	_apply_font_size()
	Indexer.save_settings()


func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/Search.tscn")
